﻿using System;
using System.Collections.Generic;
using System.Text;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;

namespace BxCTemplate.Mods
{
    internal class Panic
    {
        public static void PanicMod()
        {
            foreach (ButtonInfo[] array in Buttons.buttons)
            {
                foreach (ButtonInfo buttonInfo in array)
                {
                    bool enabled = buttonInfo.enabled;
                    if (enabled)
                    {
                        Main.Toggle(buttonInfo.buttonText);
                    }
                }
            }
            NotifiLib.ClearAllNotifications();
        }

    }
}
