﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BxCTemplate.Mods
{
    internal class SpeedBoost
    {
        public static void SpeedBoostMod()
        {
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 8f;
            GorillaLocomotion.Player.Instance.jumpMultiplier = 8f;
        }
    }
}
