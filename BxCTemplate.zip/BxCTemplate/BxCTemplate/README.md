# BxC Template
BxC Template is a mod menu template for Gorilla Tag with custom categories and the maximum amount of customization possible. This template is meant for more advanced users, so if you're a new menu creator, this could be difficult for you.

## Do I need permission to use this?
No, this template is free and public for anyone to use. You are welcome to use it for your projects, modify it to suit your needs, and share it with others. I believe in a collaborative and open community where resources are accessible to all. Js don't skid, cus skidding is for weirdos.

---

# Installation

- Change your `<GamePath>` (Gorilla Tag directory) in `Directory.Build.props` if required
- Change the menu name in `PluginInfo.cs`
- Edit the menu visuals in `Menu/Settings.cs`
- Add buttons in `Menu/Buttons.cs`
- Build with `Ctrl` + `B`, it will get put in your plugins folder automatically
- Add Mods By Right Clicking The `Mods` Folder, Clicking `Add`, And Clicking `New Item`, And Finnaly, Adding Your Code.