﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.babyboba.gorillatag.menutemplate";
        public const string Name = "BxC Template";
        public const string Description = "Created by @babybobaontop with hate >:(";
        public const string Version = "1.0.0";
    }
}
